To get HttpSocket sample work, you need to set up your Http server: 

1. Install http server, for example, Internet Information Services (IIS) on Windows XP Professional.

2. Extract \HttpSocket_sample_path\Media\DataFiles\HttpSocketServerFiles.zip
   and copy all the files to your http server's web root folder, default is C:\Inetpub\wwwroot. 

3. Grant write permission of XboxHttpSocket.mdb to Internet Guest Account. 

4. Make sure "The Microsoft Jet 4.0 OLE DB Provider" is installed.
   The easiest way is to install Microsoft Access 2003 or above on your Http server machine. 

5. Test with your PC browser: http://your_http_server/XboxHttpSocketResult.asp 
