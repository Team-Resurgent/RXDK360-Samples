<META HTTP-EQUIV="refresh" content="60;URL=./XboxHttpSocketResult.asp ">
<META NAME="COPYRIGHT" CONTENT="Copyright (C)  Microsoft Corporation.">
<META NAME="DESCRIPTION" CONTENT="Disaplay the result of Access database, auto-refresh">


<%

DIM objConn
Set objConn = Server.CreateObject("ADODB.Connection")
objConn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & _
Server.MapPath ("/XboxHttpSocket.mdb") & ";"
objConn.Open

DIM objRS
Set objRS = Server.CreateObject("ADODB.Recordset")

objRS.Open "table1", objConn, 3, 3

Response.Write("<HTML> <HEAD>"& vbCrLf)
Response.Write("<TITLE>Xbox 360 HttpSocket sample result</TITLE>" & vbCrLf)

Response.Write("</HEAD><BODY>" & vbCrLf)

Response.Write("<h2>Xbox 360 HttpSocket sample result</h2>"& vbCrLf)
Response.Write("<TABLE border = 1>" & vbCrLf & "<TR>" & vbCrLf )
    For X = 0 To objRS.Fields.Count - 1
        Response.Write("<TD>" & objRS.Fields.Item(X).Name & "</TD>" & vbCrLf)
    Next
Response.Write("</TR>" & vbCrLf)

objRS.MoveFirst

While Not objRS.EOF
    Response.Write(vbCrLf & "<TR>"& vbCrLf)
        For X = 0 To objRS.Fields.Count - 1
            Response.write("<TD>" & "&nbsp" &objRS.Fields.Item(X).Value & "</TD>"& vbCrLf )
        Next
        objRS.MoveNext
    Response.Write("</TR>" & vbCrLf & vbCrLf)
Wend
Response.Write("</TABLE>" & vbCrLf)

Response.Write( "Generated at " & now  & vbCrLf)

Response.Write("</BODY></HTML>")

objRS.Close
Set objRS = Nothing
objCONN.Close
Set objCONN = Nothing

%>


