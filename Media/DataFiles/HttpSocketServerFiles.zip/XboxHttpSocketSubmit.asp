
<%

DIM objConn
Set objConn = Server.CreateObject("ADODB.Connection")
objConn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & _
Server.MapPath ("/XboxHttpSocket.mdb") & ";"
objConn.Open

DIM objRS
Set objRS = Server.CreateObject("ADODB.Recordset")

objRS.Open "table1", objConn, 3, 3

objRS.AddNew
objRS("steps") = Request.Form("Field1")
objRS("seconds") = Request.Form("Field2")
objRS("Field3") = Request.Form("Field3")
objRS("Field4") = Request.Form("Field4")
objRS("Field5") = Request.Form("Field5")
objRS("Field6") = Request.Form("Field6")
objRS("Field7") = Request.Form("Field7")
objRS("Field8") = Request.Form("Field8")


objRS("IP") = Request.ServerVariables("REMOTE_ADDR")
objRS("time") = Now
objRS.Update

Response.Write("<TABLE border = 1><TR>")
      For X = 0 To objRS.Fields.Count - 1
         Response.Write("<TD>" & objRS.Fields.Item(X).Name & "</TD>")
      Next
Response.Write("</TR>")

      objRS.MoveFirst

      While Not objRS.EOF
         Response.Write("<TR>")
         For X = 0 To objRS.Fields.Count - 1
            Response.write("<TD>" & objRS.Fields.Item(X).Value)
         Next
         objRS.MoveNext
         Response.Write("</TR>")
      Wend
      Response.Write("</TABLE>")

objRS.Close
Set objRS = Nothing
objCONN.Close
Set objCONN = Nothing

%>


